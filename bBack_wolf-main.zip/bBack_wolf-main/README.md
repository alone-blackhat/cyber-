# CyberShield Live Attack Simulation Module

A professional, futuristic, real-time 3D Globe Security Operations Center (SOC) dashboard. This module is built specifically for security awareness, training, and educational visualization of global cyber threat vectors.

## Installation & Setup

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Run in Development Mode**
   ```bash
   npm run dev
   ```
   This will boot the full-stack server at `http://localhost:3000` with hot-rebuilding via Vite.

3. **Build & Start Production Container**
   ```bash
   npm run build
   npm start
   ```

---

## Architectural Breakdown & Core Mechanics

### 1. How Socket.IO Works
We leverage Socket.IO to provide low-latency, bidirectional, real-time message exchange between the security console and the server:
- **Automatic Initialization**: On frontend mounting, the `useSocket` React hook establishes a Socket.IO connection.
- **Bi-directional Updates**:
  - The backend server pushes newly synthesized threat vectors to the UI via `sim_event` channels.
  - Live aggregated telemetry states are pushed via `stats_update` channels.
  - Interactive commands (such as play/pause, speed multipliers, and manual simulation injectors) are sent back to the server using the `control_sim` and `inject_event` events.

### 2. Simulated Events Engine
To ensure high performance and strict safety (without scanning or targeting real-world networks):
- **Continuous Generation**: The server runs an in-memory simulation engine (`/server/simulation.ts`) which cycles based on a standard interval calibrated to the client's speed factor.
- **Detailed Threat Objects**: Every event is constructed on the fly with custom source/destination coordinates, realistic organization names, sectors, severity weights, block/mitigate status indicators, and distinct visual glow signatures.
- **Memory Optimization**: The server keeps a revolving queue of the 50 most recent events. Whenever a client connects, it fetches the backlog via REST (`/api/events`), then hot-swaps to reactive WebSocket updates.

### 3. Future authorized public Threat Intelligence Feeds integration
The architecture was strictly engineered with a decoupled design to support plug-and-play transitions to authorized live feeds:
- **No Client Re-writes**: The client receives standard `SimulatedEvent` objects regardless of backend origin.
- **Backend Adaptability**: You can easily wire `/server/simulation.ts` to query public telemetry networks (such as CISA Advisories, Shodan, AbuseIPDB, or Spamhaus) using simple fetch cycles, map them into the `SimulatedEvent` schema, and push them to Socket.IO.

---

## Directory & File Structure

```
.
â”œâ”€â”€ server/
â”‚   â””â”€â”€ simulation.ts          # Simulates threat vectors and updates analytics counters
â”œâ”€â”€ src/
â”‚   â”œâ”€â”€ components/
â”‚   â”‚   â”œâ”€â”€ Globe/
â”‚   â”‚   â”‚   â”œâ”€â”€ AttackArc.tsx      # Arc visual metadata helper
â”‚   â”‚   â”‚   â”œâ”€â”€ GlobeScene.tsx     # 3D Auto-rotating Globe.gl with impact ripples
â”‚   â”‚   â”‚   â”œâ”€â”€ CountryMarker.tsx  # Geographical annotator
â”‚   â”‚   â”‚   â”œâ”€â”€ ImpactRing.tsx     # Ripple impact animations
â”‚   â”‚   â”‚   â””â”€â”€ FlashEffect.tsx    # High-severity alert strobe highlights
â”‚   â”‚   â”œâ”€â”€ EventFeed.tsx          # Real-time animated vertical incident cards
â”‚   â”‚   â”œâ”€â”€ StatsCards.tsx         # Real-time cumulative grid metrics
â”‚   â”‚   â”œâ”€â”€ ThreatCharts.tsx       # Dynamic Chart.js widgets
â”‚   â”‚   â”œâ”€â”€ FilterPanel.tsx        # High-precision operational matrix filter cards
â”‚   â”‚   â””â”€â”€ SimulationControls.tsx # Interactive speed, play/pause and injectors
â”‚   â”œâ”€â”€ constants/
â”‚   â”‚   â”œâ”€â”€ countries.ts           # Globe coordinates and flag data lookup
â”‚   â”‚   â””â”€â”€ threatTypes.ts         # Colors and descriptions of various vector classes
â”‚   â”œâ”€â”€ hooks/
â”‚   â”‚   â””â”€â”€ useSocket.ts           # Reactive socket client state synchronizer
â”‚   â”œâ”€â”€ pages/
â”‚   â”‚   â””â”€â”€ LiveAttackSimulation.tsx # Master container page with visual headers
â”‚   â”œâ”€â”€ services/
â”‚   â”‚   â”œâ”€â”€ api.ts                 # REST client for initial stats/events load
â”‚   â”‚   â””â”€â”€ socket.ts              # Socket.io connection instance manager
â”‚   â”œâ”€â”€ main-sim.tsx               # Dedicated entry point for mounting React simulation
â”‚   â””â”€â”€ index.css                  # Core CSS definitions including Tailwind
â”œâ”€â”€ server.ts                      # Core Node.js HTTP server, Express router, and Socket.IO coordinator
â””â”€â”€ dashboard.html                 # Main dashboard layout hosting the React simulator view
```

---

## Security Compliance Notice
This visualization displays simulated cybersecurity events for awareness, education, and training. It does not represent real-time attacks by default and is designed for demonstration purposes. The architecture supports future integration with authorized public threat-intelligence feeds.
